-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 26, 2017 at 12:59 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stock`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `OTP` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `role` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `username`, `password`, `OTP`, `mobile`, `last_updated`, `role`) VALUES
(1, 'abc@example.com', 'book', 'zw72c1t', '8806893675', '2017-02-22 02:44:52', 'staff'),
(2, 'admin@gmail.com', 'admin', 'J5VTi6L', '9998887880', '2017-08-21 15:35:53', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `book_master`
--

CREATE TABLE `book_master` (
  `book_id` int(11) NOT NULL,
  `book_author` varchar(100) NOT NULL,
  `book_category` varchar(20) NOT NULL,
  `book_name` varchar(150) DEFAULT NULL,
  `book_price` int(11) DEFAULT NULL,
  `book_qty` int(11) DEFAULT NULL,
  `total_price` int(11) NOT NULL,
  `discount` float NOT NULL,
  `manufactur_date` date DEFAULT '0000-00-00',
  `book_status` int(11) DEFAULT '0',
  `barcode` varchar(110) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_master`
--

INSERT INTO `book_master` (`book_id`, `book_author`, `book_category`, `book_name`, `book_price`, `book_qty`, `total_price`, `discount`, `manufactur_date`, `book_status`, `barcode`) VALUES
(128, 'Jack', '15', 'The Action Hero', 70, 60, 4200, 25, '2017-04-06', 0, '132'),
(129, 'Aminous', '28', 'The wonder anthology', 520, 20, 10400, 25, '2017-04-06', 0, '3846671687328781'),
(130, 'Afsha', '33', 'The Popular Art', 600, 100, 60000, 10, '2017-04-06', 0, '5176827587268376'),
(149, 'jaon ', '28', 'c++', 800, 5, 4000, 0, '2017-03-27', 0, '455666666'),
(150, 'mr.john', '15', 'Avengers', 90, 66, 5940, 0, '2017-03-27', 0, '5465668768'),
(151, 'jain', '28', 'synopsis', 87, 8, 696, 0, '2017-03-27', 0, '66757'),
(155, 'k.k.', '33', 'Art Gallery', 900, 2, 1800, 0, '2017-05-08', 0, '44654656775687'),
(156, 'jack', '28', 'wolfman', 77, 99, 7623, 0, '2017-08-21', 0, '56756567557'),
(157, 'syscode', '28', 'mphasis', 900, 6, 5400, 0, '2017-08-26', 0, '9999999999999');

-- --------------------------------------------------------

--
-- Table structure for table `category_master`
--

CREATE TABLE `category_master` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_master`
--

INSERT INTO `category_master` (`category_id`, `category_name`) VALUES
(1, 'refrence'),
(3, 'novel'),
(4, 'relible'),
(12, 'Science fiction'),
(13, 'Satire'),
(14, 'Drama'),
(15, 'Action_and_Adventure'),
(16, 'Romance'),
(17, 'Mystery'),
(18, 'Horror'),
(19, 'Self_help'),
(20, 'Health'),
(21, 'Guide'),
(22, 'Travel'),
(23, 'Children_book'),
(24, 'Religion'),
(25, 'Science'),
(26, 'History'),
(27, 'Math'),
(28, 'Anthology'),
(29, 'Poetry'),
(30, 'Encyclopedias'),
(31, 'Dictionaries'),
(32, 'Comics'),
(33, 'Art'),
(34, 'Cookbooks'),
(35, 'Diaries'),
(36, 'Journals'),
(37, 'Prayer_books'),
(38, 'Series'),
(39, 'Trilogy'),
(40, 'Biographies'),
(41, 'Autobiographies'),
(42, 'Fantasy');

-- --------------------------------------------------------

--
-- Table structure for table `stock_master`
--

CREATE TABLE `stock_master` (
  `stock_id` int(11) NOT NULL,
  `book_id` int(11) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock_master`
--

INSERT INTO `stock_master` (`stock_id`, `book_id`, `qty`, `date`, `status`) VALUES
(3, 3, 3, '2017-03-27', 'new'),
(4, 55, 33, '2017-03-27', 'Damaged'),
(6, 135, 54, '2017-03-27', 'Damaged'),
(7, 128, 33, '2017-03-27', 'new'),
(8, 128, 66, '2017-03-27', 'new'),
(11, 147, 6, '2017-03-27', 'new'),
(12, 145, 6, '2017-03-27', 'new'),
(13, 149, 6, '2017-03-27', 'new'),
(14, 150, 8, '2017-03-27', 'new'),
(17, 128, 8, '2017-03-27', 'Damaged'),
(18, 150, 66, '2017-03-27', 'new'),
(19, 151, 8, '2017-03-27', 'new'),
(20, 152, 6, '2017-03-27', 'new'),
(21, 153, 8, '2017-03-27', 'new'),
(22, 135, 6, '2017-03-27', 'Damaged'),
(23, 147, 4, '2017-03-27', 'Damaged'),
(24, 135, 99, '2017-04-11', 'new'),
(25, 154, 8, '2017-04-11', 'new'),
(26, 150, 20, '2017-04-11', 'new'),
(27, 150, 9, '2017-05-08', 'new'),
(28, 150, 7, '2017-05-08', 'Damaged'),
(29, 155, 8, '2017-05-08', 'new'),
(30, 155, 20, '2017-05-08', 'Damaged'),
(31, 155, 4, '2017-08-21', 'Damaged'),
(32, 150, 40, '2017-08-21', 'Damaged'),
(33, 147, 20, '2017-08-21', 'Damaged'),
(34, 156, 9, '2017-08-21', 'new'),
(35, 156, 90, '2017-08-21', 'new'),
(36, 128, 3, '2017-08-26', 'Damaged'),
(37, 157, 6, '2017-08-26', 'new'),
(38, 0, 8, '2017-08-26', 'new');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book_master`
--
ALTER TABLE `book_master`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `category_master`
--
ALTER TABLE `category_master`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `stock_master`
--
ALTER TABLE `stock_master`
  ADD PRIMARY KEY (`stock_id`),
  ADD KEY `fk15` (`book_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `book_master`
--
ALTER TABLE `book_master`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=158;
--
-- AUTO_INCREMENT for table `category_master`
--
ALTER TABLE `category_master`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT for table `stock_master`
--
ALTER TABLE `stock_master`
  MODIFY `stock_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
