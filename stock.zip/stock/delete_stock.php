<?php
include('database.php');
if($_POST['del_id'])
{
$id = $_POST['del_id']; 
$delete = "DELETE FROM `stock_master` WHERE stock_id='$id'";

mysqli_query($con,$delete);
}

?>