<?php

include('database.php');

$Id = $_GET['Id'];

$query=mysqli_query($con,"select book_name,book_author,s.book_id,stock_id,date,status,category_name,book_price from stock_master as s,book_master as b,category_master as c where b.book_id=s.book_id and b.book_category=c.category_id and stock_id='$Id'");

while($row=mysqli_fetch_array($query))
{
?>
<center><strong>Basic Information</strong></center><br/>

<form class="form-horizontal col-sm-12">

          <div class="form-group">
          <table class="table  table-striped  table-bordered table-advance table-hover"><tr><th>Stock Id :</th><th>Book Id</th><th>Category</th><th>Author</th><th>Name</th><th>Price</th></tr>
          <tr><td><?php echo $row['stock_id'];?></td>
         <td> <?php echo $row['book_id'];?></td>
           <td><?php echo $row['category_name'];?></td>
           <td> <?php echo $row['book_author'];?></td>
           <td> <?php echo $row['book_name'];?></td>
           <td><?php echo $row['book_price'];?></td></tr>
           </table>
         
          </div>

          	<!--hr style="border-top: 1px solid #ccc !important" />-->
<center><strong>Detailed Information</strong></center><br/>

          <div class="col-md-12">
                        <table class="table table-striped table-bordered table-advance table-hover display" id="myTable">
                            <thead>
                              <tr>
                                 <th> Book Status</th>
                                 <th>Book Quantity</th>
                                 <th>Stock Date</th>
                                
                                 
                              </tr>
                            </thead>


         <?php

         $book_id=$row['book_id'];
         $query1=mysqli_query($con,"select status,qty,date from stock_master where book_id='$book_id'");



         while($row1=mysqli_fetch_array($query1))
         {

			?>
			
                     <tbody>

          			<tr><td><?php echo $row1['status'];?></td> 
          			<td><?php echo $row1['qty'];?></td>
          			<td><?php echo $row1['date'];?></td></tr>
          			</tbody>
        <?php
      		}
      	?>
          </table>

           <?php
           $book_id=$row['book_id'];
        
          $q=mysqli_query($con,"select sum(qty) from stock_master where book_id='$book_id'");
          while($row2=mysqli_fetch_array($q))
          {

          ?>

          <div class="form-group text-center"><label><strong>Total Quantity :</strong></label>&nbsp;&nbsp;&nbsp;<?php echo $row2['sum(qty)'];?></div>
          <?php
          }
          ?>
          
         <!--  <div class="form-group"><button type="submit" class="btn btn-success pull-right">Send It!</button> <p class="help-block pull-left text-danger hide" id="form-error">&nbsp; The form is not valid. </p></div>
  -->       </form>






<?php
}
?>