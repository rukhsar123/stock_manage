// JavaScript Document

$(document).ready(function(){
 
 /* Data Insert Starts Here */
 $(document).on('submit', '#register_form', function() {
   
    $.post("insert_book.php", $(this).serialize())
        .done(function(data){
   $("#dis").fadeOut();
   $("#dis").fadeIn('slow', function(){
     $("#dis").html('<div class="alert alert-info">'+data+'</div>');
        $("#register_form")[0].reset();
       }); 
   });   
      return false;
    });
 /* Data Insert Ends Here */
 
 
 /* Data Delete Starts Here */
 /*$(".delete-link").click(function()
 {
  var parent = $(this).parent("td").parent("tr");
  if(confirm('Sure to Delete ID no = ' +del_id))
  {
   $.post('deletedispatch.php', {'del_id':del_id}, function(data)
   {
    parent.fadeOut('slow');
   }); 
  }
  return false;
 });*/
 /* Data Delete Ends Here */
 
 /* Get Edit ID  */
 $(".edit-link").click(function()
 {
  var id = $(this).attr("id");
  var dispatch_id = id;
  if(confirm('Are you sure you want to edit this dispatch details having dispatch id = ' +dispatch_id))
  {
   $(".content-loader").fadeOut('slow', function()
    {
    $(".content-loader").fadeIn('slow');
    $(".content-loader").load('editdispatch.php?dispatch_id='+dispatch_id);
    $("#btn-add").hide();
    $("#btn-view").show();
   });
  }
  return false;
 });
 /* Get Edit ID  */
 
 /* Update Record  */
 $(document).on('submit', '#updateform', function() {
  
    $.post("editdispatch1.php", $(this).serialize())
        .done(function(data){
   $("#dis").fadeOut();
   $("#dis").fadeIn('slow', function(){
        $("#dis").html('<div class="alert alert-info">'+data+'</div>');
        $("#updateform")[0].reset();
     $("body").fadeOut('slow', function()
     {
     $("body").fadeOut('slow');
     window.location.href="view_dispatch.php";
     });     
       }); 
  });   
     return false;
    });
 /* Update Record  */
});
