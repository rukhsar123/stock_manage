<!-- javascripts -->
	<!-- <script src="jquery/jquery.js"></script>
 -->
    <script>
        $(document).ready(function(){
            $('#myTable').dataTable();
        });
    </script>

    <script src="js/bootstrap.min.js"></script>
    <!-- nice scroll -->
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script><!--custome script for all page-->
    <script src="js/scripts.js"></script>


  </body>

  


</html>
