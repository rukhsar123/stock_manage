<?php
// Start the session
session_start();
include('database.php');
include ('logout.php');

?>
<style>
table {
    border-collapse: collapse;
    width: 100%;
}
th {
    background-color: #eeeeee;
    color: white;
    text-align: center;
}
th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
.modal-dialog {
  height: 80% !important;
  padding-top:10%;
}

.modal-content {
  height: 100% !important;
  overflow:visible;
}

.modal-body {
  height: 80%;
  overflow: auto;
}
</style>

<style type="text/css">
    #dis{
        display: none;
    }
</style> 
    <div id="dis">
    </div>
  


<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    

    <title>Library Management</title>

    <!-- Bootstrap CSS -->    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
    <link rel="shortcut icon" href="img/favicon.png">
    
    <script src="jquery/jquery-3.1.1.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/jquery.dataTables.min.css">
    <script type="text/javascript" src="js/jquery.datatables.min.js"></script>

 </head>

  <?php 
      include('header.php');
      include('sidebar.php');
      ?>
    

  <body>
  <!-- container section start -->
  <section id="container" class="">
      <!--header start-->



     
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
          <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header"><i class="fa fa-files-o"></i>Book Master
                      <div class="navbar-form pull-right">
                                      <a href="bookmaster.php"><button class="btn btn-primary" type="button"><span class="fa fa-plus-square" aria-hidden="true"></span> Add Books</button></a>
                                    </div>
                    </h3>
<!--                     <ol class="breadcrumb">
                        <li><i class="fa fa-home"></i><a href="index.html">Dashboard</a></li>
                        <li><i class="icon_document_alt"></i>Book Master</li>
                    </ol>
 -->                </div>
            </div>
                          
              <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                                <header class="panel-heading">
                              Books Details
                                    
                                 </header>
                              <div class="container">

                                <table class="table table-striped table-bordered table-hover display" id="myTable"> 
                                  <thead >
                                    <tr>
                                      <th>id
                                      <i class="fa fa-sort"></i></th>
                                      <th> Author
                                      <i class="fa fa-sort"></i></th>
                                      <th>Category
                                      <i class="fa fa-sort"></i></th>
                                      <th>Name
                                      <i class="fa fa-sort"></i></th>
                                      <th> Price
                                      <i class="fa fa-sort"></i></th>
                                      <th>Qty
                                      <i class="fa fa-sort"></i></th>
                                      <th> Mf_Date
                                      <i class="fa fa-sort"></i></th>
                                      <th>Status
                                      <i class="fa fa-sort"></i></th>
                                      <!-- <th><i class="fa fa-hashtag">#Barcode</i></th> -->
                                      <th><i class="fa fa-cogs"> Action</i></th>
                                    </tr>
                                  </thead>
                                  <tbody>  
                                                        <?php
                                                          $id=0;
                                                            $query=mysqli_query($con,"SELECT * FROM book_master,category_master WHERE book_category=category_id ORDER BY book_id DESC");
                                                            while($row=mysqli_fetch_array($query))
                                                            {
                                                              $id++;
                                                                echo "<td>".$id."</td>";
                                                                $book_id=$row['book_id'];
                                                                echo "<td>".$row['book_author']."</td>";
                                                                echo "<td>".$row['category_name']."</td>";
                                                                echo "<td>".$row['book_name']."</td>";
                                                                echo "<td>".$row['book_price']."</td>";
                                                                echo "<td>".$row['book_qty']."</td>";
                                                                echo "<td>".$row['manufactur_date']."</td>";
                                                                if($row['book_status']==0)
                                                                {
                                                                    echo "<td>Available</td>";
                                                                }
                                                                else
                                                                {
                                                                    echo "<td>Unavailable</td>";
                                                                }
                                                                // echo "<td>".$row['barcode']."</td></small>";
                                                                
                                                            ?>
                                                            <td>
                                                            <div class="btn-group">
                                                              <a href="#myModal" role="button" class="btn btn-primary view" id=<?php echo $book_id;?> data-toggle="modal"><i class="fa fa-eye"></i></a>
                                                            <a href="update_bookmaster.php?book_id=<?php echo $row['book_id'];?>" class="btn btn-success"><i class="fa fa-pencil"></i></a>
                                                            <a id=<?php echo $row['book_id'];?> class="btn btn-danger delete"><i class="icon_close_alt2"></i></a>
                                                            </div>
                                                            </td>
                                                            </tr>
                                                            <?php
                                                            }
                                                            ?>
                                                            
                                  </tbody>  
                                </table>
                                </div>
                                </div>
                              </div>
                          </div>
                      </section>
                  </div>
              </div>
              <!-- page end-->
          </section>
      </section>
      <!--main content end-->
      <div class="text-right">
        <div class="credits">
            <!-- 
                All the links in the footer should remain intact. 
                You can delete the links only if you purchased the pro version.
                Licensing information: https://bootstrapmade.com/license/
                Purchase the pro version form: https://bootstrapmade.com/buy/?theme=NiceAdmin
            
            <a href="https://bootstrapmade.com/free-business-bootstrap-themes-website-templates/">Business Bootstrap Themes</a> by <a href="https://bootstrapmade.com/">BootstrapMade</a>-->
        </div>
    </div>
  </section>


<div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="myModalLabel">Book Details:</h3>
      </div>
      <div class="modal-body">
      </div>
      <div class="modal-footer">
        <button class="btn btn-danger" data-dismiss="modal" aria-hidden="true">Close</button>
      </div>
    </div>
  </div>
</div>
  <!-- container section end -->
    <!-- javascripts -->
    <script src="js/bootstrap.min.js"></script>
    <!-- nice scroll -->
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
    <!-- jquery validate js -->
    <script type="text/javascript" src="js/jquery.validate.min.js"></script>

    <!-- custom form validation script for this page-->
    <script src="js/form-validation-script.js"></script>
    <!--custome script for all page-->
    <script src="js/scripts.js"></script>    
    
  </body>
  <script type="text/javascript">
            $(document).ready(function(){
            
            $(".delete").click(function(){
                var id = $(this).attr("id");
                var del_id =id;
                if(confirm('Are You Sure want to delete ID no = ' +del_id+'?'))
                {
                    $.post('delete_book.php', {'del_id':del_id}, function(data)
                    {
                        alert(data);
                        window.location.href="view_book.php";
                    }); 
                }
            return false;
                });
            });

        </script>

<script type="text/javascript">
      $(document).ready(function(){
             // alert();
            
            $(".view").click(function(){
                var id = $(this).attr('id');
                //alert(id);
                $.ajax({

                  url:"modal_book.php?id="+id,
                  cache:false,
                  success:function(result)
                   {

                    $(".modal-body").html(result);
                    // body...
                  }
                });
                
            });

          });

        </script>



  <script>
        $(document).ready(function(){
            $('#myTable').dataTable();
        });
    </script>

</html>
