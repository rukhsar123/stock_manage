<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link rel="shortcut icon" href="img/favicon.png">
    <title>Login Page</title>
    <!-- Bootstrap CSS -->    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
    
</head>
  <body class="login-img3-body">
    <div class="container">
      <form id="login_form" method="post" class="login-form" name="form1" action=""  style="margin: 40px auto 0 !important;">        
        <div class="login-wrap">
            <p class="login-img"><i class="icon_lock_alt"></i></p>

            <div class="input-group">
              <span class="input-group-addon"></i></span>
              <?php 
                include ('database.php');
                $query=mysqli_query($con,"SELECT role FROM admin_login ORDER BY role ASC");
                $rowCount = $query->num_rows;
                ?>
                <select name="role" id="role" class="form-control" required>
                <option value="">Select Role</option>
                <?php
                    if($rowCount > 0)
                    {
                        while($row = $query->fetch_assoc()){ 
                        echo '<option value="'.$row['role'].'">'.$row['role'].'</option>';
                        }
                        }else{
                        echo '<option value="">Role not available</option>';
                    }
                ?>
                </select>
                                                    
            </div>

            <div class="input-group">
              <span class="input-group-addon"><i class="icon_profile"></i></span>
              <input type="text" id="username" name="username" class="form-control" placeholder="Username" required>
            </div>

            <div class="input-group">
              <span class="input-group-addon"><i class="icon_key_alt"></i></span>
              <input type="password" id="password" name="password" class="form-control" placeholder="Password" required="" size="15" maxlength="8" >
            </div>

            <label class="checkbox">
                <span class="pull-right"> <a href="forgot_password.php"> Forgot Password?</a></span>
            </label>
 
            <button class="btn btn-primary btn-lg btn-block" type="submit" >Login</button>
            </div>
      </form>
    </div>
    <script src="js/jquery.js"></script>
    <script type="text/javascript">
    $(document).ready(function(){
        $(document).on('submit','#login_form',function(){
             $.post("dblogin.php", $(this).serialize())
             .done(function(data){
                    alert(data); 
                    if(data == 'success'){
                    window.location.href = "http:index.php";
                    $("#login_form")[0].reset();
                    } else {
                    window.location.href = "http:login.php";
                    $("#login_form")[0].reset();
                    }
            });    
            return false;
        });
        $(document).on('click','#login',function(){
            document.location.href="#";
        });
      });
      </script>
    </body>
</html>