<?php
include("database.php");
//print_r($_POST);exit();
if($_POST['id'])
{
$id=$_POST['id'];
$qty=$_POST['firstname'];
//$lastname=mysql_escape_String($_POST['lastname']);
$sql = mysqli_query($con,"update stock_master set qty='$qty' where stock_id='$id'");
if($sql)
{
	echo "Quantity Updated Successfully";
}
else
{
	echo "error";
}

}
?>