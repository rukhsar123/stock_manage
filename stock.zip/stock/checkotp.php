<?php

require_once 'database.php';

$current=$_POST['current'];
$username=$_POST['username'];

setcookie("cookie",$username);

$query=mysqli_query($con,"select OTP,password from admin_login where username='$username'");

while($row=mysqli_fetch_array($query))
{
  $otp=$row['OTP'];
  //$password=$row['password'];
}

if($current!=$otp)
{
  echo "OTP Does Not Match";
 ?>

<script type="text/javascript">
//$("#username").val('');
document.form1.otp.focus();
                     
</script>


 <?php
}
else
{

 ?>
  

  <script type="text/javascript">
  	alert("password Restore Successfully");
	document.location.href="restore_password.php";
  </script>


<?php
}

?>