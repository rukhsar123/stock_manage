<?php
include('database.php');
 echo "<h3>Book details of book id ::".$_GET['id']."</h3>";
$id=$_GET['id'];
$s=null;
$query=mysqli_query($con,"SELECT * FROM book_master,category_master WHERE book_id='$id'");

    $row=mysqli_fetch_array($query);
            $book_author=$row['book_author'];
            $book_name=$row['book_name'];
            $book_price=$row['book_price'];
            $book_qty=$row['book_qty'];
            $total=$book_price*$book_qty;
            $book_status=$row['book_status'];
            if($row['book_status']==0)
            {
                $s="Available";
            }
            else
            {
                $s="Unavailable";
            }    
            // $book_category=$row['book_category'];
            $barcode=$row['barcode'];    
            $category_name=$row['category_name'];
        ?>
        <br><br>
        <div class="form-group ">
          <label for="bname" class="control-label col-lg-2">Name :</label>
          <div class="col-lg-4">
              <label><?php echo $book_name;?></label>
          </div>
                                                    
          <label for="bprice" class="control-label col-lg-2">Author :</label>
          <div class="col-lg-4">
                <label><?php echo $book_author;?></label>
          </div>
        </div>
         <br><br>
        <div class="form-group ">
          <label for="bname" class="control-label col-lg-2">Price :</label>
          <div class="col-lg-4">
              <label><?php echo $book_price;?></label>
          </div>
                                         
          <label for="bprice" class="control-label col-lg-2">Quantity :</label>
          <div class="col-lg-4">
                <label><?php echo $book_qty;?></label>
          </div>
        </div>
        <br><br>
        <div class="form-group ">
          <label for="bname" class="control-label col-lg-2">total :</label>
          <div class="col-lg-4">
              <label><?php echo $total;?></label>
          </div>
                                         
          <label for="bprice" class="control-label col-lg-2">Status :</label>
          <div class="col-lg-4">
                <label><?php echo $s;?></label>
          </div>
        </div>
        <br><br>
        <div class="form-group ">
          <label for="bname" class="control-label col-lg-2">Category :</label>
          <div class="col-lg-4">
              <label><?php echo $category_name;?></label>
          </div>
                                         
          <label for="bprice" class="control-label col-lg-2">Barcode :</label>
          <div class="col-lg-4">
                <label><?php echo $barcode;?></label>
          </div>
        </div>
        