<?php
require_once 'database.php';
session_start();
$user=$_SESSION["user"];

if($_POST)
{
	$currentpwd=$_POST['currentpwd'];
	$newpwd=$_POST['newpwd'];
	$cnewpwd=$_POST['cnewpwd'];
	

	//admin and password check
    $query=mysqli_query($con,"select id,username,password from admin_login where username='$user'") or die(mysqli_error());
    while($row=mysqli_fetch_array($query))
    {
    	$id=$row['id'];
    	$username=$row['username'];
        $pass=$row['password'];
        if($pass==$currentpwd)
        {	
		mysqli_query($con,"update admin_login set password='$cnewpwd' where id='$id'") or die(mysqli_error());
			echo "Password Change Successfully";
		}
		else
		{
			echo "Current Password Does Not Match!!";
		}
	}		
}
?>