<?php
require_once 'database.php';

	// print_r($_POST);exit();
	if($_POST)
	{
		$id=$_POST['id'];
		// echo $id;
		$stud_name=$_POST['stud_name'];
		$address=$_POST['address'];
        $stud_class=$_POST['stud_class'];
        $roll_no=$_POST['roll_no'];
        $stud_contact_no=$_POST['stud_contact_no'];
        $stud_email_id=$_POST['stud_email_id'];
		
		$query = mysqli_query($con," UPDATE `student_master` SET `stud_name`='$stud_name',`address`='$address',`stud_class`='$stud_class',`roll_no`='$roll_no',`stud_contact_no`='$stud_contact_no',`stud_email_id`='$stud_email_id' WHERE stud_id='$id'") or die(mysqli_error());

		echo "Updated Successfully!!!";
		
	}

?>