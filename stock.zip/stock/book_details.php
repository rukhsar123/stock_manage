<?php

$stud_id=$_GET['Id'];

require_once 'database.php';
?>

 <div class="col-md-12">
         <table class="table table-striped table-bordered table-advance table-hover display" id="myTable">
                            <thead>
                              <tr>
                                 <th>Book ID</th>
                                 <th>Book Name</th>
                                 <th>Book Author</th>
                                 <th>Issued Date</th>
                                 <th>Return Date</th>
                                 <th>Fine</th>
                                
                                 
                              </tr>
                            </thead>


         <?php

         
         $query1=mysqli_query($con,"select * from book_entry as be,book_master as b where be.book_id=b.book_id and stud_id='$stud_id' and be.status='received'");



         while($row1=mysqli_fetch_array($query1))
         {

			?>
			
                     <tbody>

          			<tr><td><?php echo $row1['book_id'];?></td> 
          			<td><?php echo $row1['book_name'];?></td>
          			<td><?php echo $row1['book_author'];?></td>
          			<td><?php echo $row1['issue_date'];?></td>
          			<td><?php echo $row1['actual_return_date'];?></td>
          			<td><?php echo $row1['fine'];?></td>
          			
          			</tr>
          			</tbody>
        <?php
      		}
      	?>
          
</table>
</div>