<?php

require_once 'database.php';

$searchTerm = $_GET['term'];
//get matched data from skills table
$query = mysqli_query($con,"SELECT DISTINCT book_name,book_author FROM book_master AS b,stock_master AS s WHERE b.book_id=s.book_id AND book_name LIKE '%".$searchTerm."%' ORDER BY book_name ASC") or die(mysqli_error());
while ($row = mysqli_fetch_assoc($query)) 
{
    $data[] = $row['book_name']."(".$row['book_author'].")";
}
//return json data
echo json_encode($data);
?>