<?php
// Start the session
session_start();
include('database.php');
include ('logout.php');

?>

<style type="text/css">
    #dis{
        display: none;
    }
</style>
    <div id="dis">
    </div>

<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    

    <title>Library Management</title>

    <!-- Bootstrap CSS -->    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
    <link rel="shortcut icon" href="img/favicon.png">

    <script src="jquery/jquery-3.1.1.min.js"></script>
    
 </head>

  <body>
  <!-- container section start -->
  <section id="container" class="">
      <!--header start-->

  <?php 
    include('header.php');
    include('sidebar.php');
  ?>
  <!--     <script>
    function showEdit(editableObj) {
      $(editableObj).css("background","#FFF");
    } 
    
    function saveToDatabase(editableObj,column,id) {
      $(editableObj).css("background","#FFF url(loaderIcon.gif) no-repeat right");
      $.ajax({
        url: "saveedit.php",
        type: "POST",
        data:'column='+column+'&editval='+editableObj.innerHTML+'&id='+id,
        success: function(data){
          $(editableObj).css("background","#FDFDFD");
        }        
       });
    }
    </script>
 -->   
    <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              
              <div class="row">
                  <div class="col-lg-12">
                   <h3 class="page-header"><i class="fa fa-files-o"></i> Book Master</h3>
                   
                      <section class="panel">
                          <header class="panel-heading">
                             Book Master
                          </header>
                          <div class="panel-body">
                              <div class="form">
                                <form class="form-validate form-horizontal" method="POST" id="register_form" action="#" >
                                         <div class="form-group ">
                                                    <label for="categoryname" class="control-label col-lg-2">Category Name<span class="required">*</span></label>
                                          <div class="col-lg-4">
                                          
                                          <?php 
                                            $con=mysqli_connect("localhost","root","","bookinventory");
                                            $query=mysqli_query($con,"SELECT * FROM category_master ORDER BY category_name ASC");
                                            $rowCount = $query->num_rows;
                                            ?>

                                            <select name="category_name" id="category_name" class="form-control" required>
                                            <option value="">Select Category</option>
                                            <?php
                                                if($rowCount > 0)
                                                {
                                                while($row = $query->fetch_assoc()){ 
                                                echo '<option value="'.$row['category_name'].'">'.$row['category_name'].'</option>';
                                                 }
                                                }else{
                                                echo '<option value="">Category not available</option>';
                                                 }
                                            ?>
                                            </select>
                        
                                     
                                          </div>
                                      
                                          <label for="bauthor" class="control-label col-lg-2">Book Author <span class="required">*</span></label>
                                          <div class="col-lg-4">
                                              <input class=" form-control" placeholder="Enter Book Author" name="bauthor" type="text" id="bauthor" />
                                          </div>
                                      </div>
                                      <div class="form-group ">
                                          <label for="bname" class="control-label col-lg-2">Book Name <span class="required">*</span></label>
                                          <div class="col-lg-4">
                                              <input class="form-control " placeholder="Enter Book Name" name="bname" type="text" id="bname" />
                                          </div>
                                                                         
                                          <label for="bprice" class="control-label col-lg-2">Book Price <span class="required">*</span></label>
                                          <div class="col-lg-4">
                                              <input class="form-control " placeholder="Enter Book Price" name="bprice" type="text" size="15" maxlength="4" onkeypress="return isNumberKey(event)" id="bprice" />
                                          </div>
                                    </div>
                                    <div class="form-group ">
                                          <label for="bqty" class="control-label col-lg-2">Book Quantity <span class="required">*</span></label>
                                          <div class="col-lg-4">
                                              <input class="form-control " placeholder="Enter Book Quantity" name="bqty" id="bqty" type="text" size="15" maxlength="4" onkeypress="return isNumberKey(event)" onkeyup="return calc()" / >
                                          </div>
                                        <label for="total" class="control-label col-lg-2">Total Price <span class="required">*</span></label>
                                        <div class="col-lg-4">
                                                <input class="form-control " placeholder="Book Total" readonly="readonly" name="totalprice" id="totalprice" type="text" onkeypress="return isNumberKey(event)"/ />
                                          </div>
                                                                                  </div>      
                                        <div class="form-group">                                
                                      <label for="discount" class="control-label col-lg-2">Discount <span class="required">*</span></label>
                                        <div class="col-lg-4">
                                                <input class="form-control " placeholder="Enter Book Discount" required="" name="discount" id="discount" type="text"  onkeypress="return isNumberKey(event)"/>
                                          </div>
                                        <label for="sellingprice" class="control-label col-lg-2">Selling Price <span class="required">*</span></label>
                                        <div class="col-lg-4">
                                                <input class="form-control " placeholder="Book Selling Price" readonly="readonly" name="sellingprice" id="sellingprice" type="text" onkeypress="return isNumberKey(event)"/ onkeyup="return calc1()"/>
                                          </div>

                                        </div>
                                      <div class="form-group">    
                                      <label for="bstatus" class="control-label col-lg-2">Book Status <span class="required">*</span></label>
                                        <div class="col-lg-4">
                                                <input class="form-control " readonly="readonly" name="bstatus" placeholder=" Book Ststus" id="bstatus" type="text" onkeypress="return isNumberKey(event)"/ />
                                          </div>
                                         <label for="barcode" class="control-label col-lg-2">Barcode Number <span class="required">*</span></label>
                                          <div class="col-lg-4">
                                              <input class="form-control " placeholder="Enter Barcode" name="barcode" type="text" size="15" maxlength="16" onkeypress="return isNumberKey(event)" required="" id="barcode" />
                                          </div>
                                 
                                </div>
                                <div class="form-group">
                                          <div class="col-lg-offset-2 col-lg-10">
                                              
                                              <button class="btn btn-success" type="submit" name="btn-save" value="Save" id="btn-save"><span class="fa fa-save" aria-hidden="true"></span>  Save</button>
                                              <a href="view_book.php"><button class="btn btn-primary" type="button"><span class="fa fa-eye" aria-hidden="true"></span> View</button></a>
                                          <div class="col-lg-offset-11 col-lg-10">
                                              </div>     
                                          </div>
                                </div>
                                  </form>
                              </div>
                          </div>
                      </section>
                  </div>
              </div>
              <!-- page end-->
          </section>
      </section>
      <!--main content end-->
      <div class="text-right">
        <div class="credits">
            <!-- 
                All the links in the footer should remain intact. 
                You can delete the links only if you purchased the pro version.
                Licensing information: https://bootstrapmade.com/license/
                Purchase the pro version form: https://bootstrapmade.com/buy/?theme=NiceAdmin
            
            <a href="https://bootstrapmade.com/free-business-bootstrap-themes-website-templates/">Business Bootstrap Themes</a> by <a href="https://bootstrapmade.com/">BootstrapMade</a>-->
        </div>
    </div>
  </section>
  <!-- container section end -->
    

<?php include ('footer.php') ;?>
    <script>
    //Empty Field Validation
    var Script = function () {
    $().ready(function() {
        // validate the comment form when it is submitted
        $("#feedback_form").validate();

        // validate signup form on keyup and submit
        $("#register_form").validate({
            rules: {
                category_name: {
                    required: true,
                },
                bauthor: {
                    required: true,
                },
                bname: {
                    required: true,
                },
                bprice: {
                    required: true,
                },
                bqty: {
                    required: true,
                },
                bstatus: {
                    required: true,
                },
            },
            messages: {                
                category_name: {
                    required: "Please Select Category Name.",
                },
                bauthor: {
                    required: "Please enter a  Book Author.",
                },
                bname: {
                    required: "Please enter a Book Name.",
                },
                bprice: {
                    required: "Please provide a Book Price.",
                },
                bqty: {
                    required: "Please provide a Book Quantity.",
                },
                bstatus: {
                    required: "Please provide a Book status.",
                },
                
            }
        });
    });
}();

    //Enter key Number Validation
    function isNumberKey(evt)
    {
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
        return true;
    }

    function calc()
    {
        var bookprice = document.getElementById('bprice').value;
        if(bookprice<=0)
        {
          alert('Enter Valid Price');
          document.getElementById('bprice').focus();
          document.getElementById('bprice').value="";
        }
        var bookqty = document.getElementById('bqty').value;
        document.getElementById('totalprice').value = bookprice*bookqty; 
    }
    function calc1()
    {
        var bookprice = document.getElementById('bprice').value;
        var discount = document.getElementById('discount').value;
        var sellingprice = bookprice - (bookprice * (discount / 100));
        var selling = document.getElementById('sellingprice').value = sellingprice;
        if(selling<=0)
        {
          alert('Enter Valid Discount');
          document.getElementById('discount').focus();
          document.getElementById('discount').value="";
          document.getElementById('sellingprice').value="";
        } 
    }
    $(document).ready(function() {
 
    $("#bqty").change(function(){
 
        var book_qty = $(this).val();
        var book_status = $(this).val();
        if(book_qty==0 && book_qty<=0)
        {
            alert('Book Quantity Must not be zero or less than zero');
            $("#bstatus").val('Unavailable');
            $("#bqty").focus();
        }

        if(book_qty!=0 && book_qty>0)
        {
            $("#bstatus").val('Available');            
        }     
    });
 
    });
    </script>

<script type="text/javascript" src="crud1.js"></script>

  </body>
</html>
