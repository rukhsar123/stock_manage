<?php
require_once 'database.php';
if($_POST)
    {
           $username=$_POST['username'];
           echo $username;
           $string = 'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
           $string_shuffled = str_shuffle($string);
           $otp = substr($string_shuffled, 1, 7);



           $password = base64_encode($password);
           $query = mysqli_query($con,"UPDATE admin_login SET OTP='$otp' WHERE username = '$username'") or die(mysqli_error());
           //$qry_run = mysql_query($query);

           $res=mysqli_query($con,"select * from admin_login where username='$username'");
           while ($row=mysqli_fetch_array($res))
           {
             $otp=$row['OTP'];
             $mobile=$row['mobile'];
             $password=$row['password'];
           }

           
          /*$hrmsg="hiii+".$username."+Your+OTP+is+".$otp;
    
          $hrurl="http://mysms.tejitsolutions.com/api/mt/SendSMS?apikey=M7c3MYi2pE6xGwLq7k882Q&senderid=BookInventory&channel=Trans&DCS=0&flashsms=0&number=$mobile&text=$hrmsg&route=04";

          $hrsms = curl_init();
          curl_setopt($hrsms,CURLOPT_URL, $hrurl);
          $result_h_sms = curl_exec($hrsms);
          curl_close($hrsms);

*/
     }
     
 ?>