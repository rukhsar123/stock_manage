<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Login Page </title>

    <!-- Bootstrap CSS -->    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
<script src="js/jquery.js"></script>
  
<script type="text/javascript">
   $(document).ready(function(){ 

    $("#login_form").find("#username").on("change",function(){
            var current=$('input:text[name=username]').val();
            
            jQuery.ajax({
                url: "check_username.php",
                data:'username='+$("#username").val(),
                type: "POST",
                success:function(data)
                {
                    //alert(data);
                    $(".output").html(data);
                     //$("#loaderIcon").hide();
                },
                error:function (){}
                
                });            

            

        });



    $("#login_form").find("#restore").on("click",function(){
            var current=$('#otp').val();
            var username=$('#username').val();
            
            var postdata='&current='+current+'&username='+username;

            $.ajax({

                url:"checkotp.php",
                type:"POST",
                data:postdata,
                success:function(data,status,xhr)
                {
                    $(".output1").html(data);
                    
                    //alert(data);
                    //document.href.location="login.php";
                }

            });

        });


            

});
</script>

</head>

  <body class="login-img3-body">

    <div class="container">

      <form class="form-validate login-form" name="form1" id="login_form" style="margin: 180px auto 0 !important;">        
        <div class="login-wrap">
            <p class="login-img"><i class="icon_lock_alt"></i></p>
            <p>Forgot Passoword</p>

            
            <div class="input-group">
                <span class="input-group-addon"><i class="icon_profile"></i></span>
                <input type="text" class="form-control" name="username" id="username" placeholder="Username" required="">
                
            </div>
            
            <span class="output" style="color: red !important;"></span>

            <div class="input-group">
                <span class="input-group-addon" id="key"><i class="icon_key_alt"></i></span>
                <input type="text" class="form-control" name="otp" id="otp" placeholder="OTP" size="15" maxlength="8" >
            
            </div>


            <span class="output1" style="color: red !important;"></span>

            

            <label class="checkbox">
                <span class="pull-left"> <a href="login.php"> Admin Login</a></span>
            
                <span class="pull-right"> <a href="change_password.php"> Change Password?</a></span>
            </label>
            <button class="btn btn-primary btn-lg btn-block" type="submit" id="login">Generate OTP</button>
            <button class="btn btn-primary btn-lg btn-block" id="restore" type="button">Restore Password
            </button>
        </div>
    
            </form>
        </div>
<script type="text/javascript">
$(document).ready(function(){

$("#restore").hide();
$("#otp").hide();
$("#key").hide();

   $("#login_form").on("submit",function(){
            
            var username=$('input:text[name=username]').val();
            //alert(username);

            $.post("generateotp.php",$(this).serialize())
            .done(function(data){

                alert("OTP generate Successfully..");
                $("#login").hide();
                $("#key").show();
                $("#otp").show();
                $("#restore").show();
                
                


            });



            return false;

            
    });



       
});

</script>


  </body>
</html>
