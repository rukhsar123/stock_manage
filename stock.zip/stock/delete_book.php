<?php
include('database.php');

$id = $_POST['del_id'];

$delete = "DELETE FROM `book_entry` WHERE book_id='$id'";

$delete1 = "DELETE FROM `book_master` WHERE book_id='$id'";

$res=mysqli_query($con,$delete1);
if($res)
{
	echo "Record Deleted Successfully";
}
else
{
	echo "Not Deleted";
}


?>