<?php

//print_r($_POST);
require_once 'database.php';

$book_name=$_POST['bname'];
$qty=$_POST['qty'];
$date=$_POST['date'];
$status=$_POST['status'];

$first=explode('(', $book_name);
$bname=$first[0];//book_name

$regex = '#\((([^()]+|(?R))*)\)#';
if (preg_match_all($regex, $book_name ,$matches)) 
{
	
    $author_name=implode('', $matches[1]);//author_name
    
} 
else 
{
    //no parenthesis
   
}

$query=mysqli_query($con,"select book_id from book_master where book_name='$bname' and book_author='$author_name'");

$row=mysqli_fetch_row($query);

$bookid=$row[0];//fetch book_id from matching book_name ans book_author

$query=mysqli_query($con,"insert into stock_master(book_id,qty,date,status) values('$bookid','$qty','$date','$status')");

if($query)
{
	echo "Stock Updated Successfully";
}
else 
{
	echo "error";
}

?>