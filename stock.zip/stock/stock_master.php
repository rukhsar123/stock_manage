<?php
// Start the session
session_start();
include('database.php');
include ('logout.php');

?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Index Page</title>

    <!-- Bootstrap CSS -->    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
    <link href="jquery/jquery-ui-1.12.1.custom/jquery-ui.css" rel="stylesheet" />
    <link href="css/jquery.multiselect.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.css">

    <script src="jquery/jquery-3.1.1.min.js"></script>
    
    <script src="jquery/jquery-ui-1.12.1.custom/jquery-ui.js"></script>

    <script src="jquery/jquery.multiselect.js"></script>

    <!-- Datatables-->

        <!-- <link rel="stylesheet" type="text/css" href="/assets/css/bootstrap.min.css"> -->

        <!-- <script type="text/javascript" src="/assets/js/jquery.min.js"></script> -->

        <link rel="stylesheet" type="text/css" href="css/jquery.dataTables.min.css">

        <script type="text/javascript" src="js/jquery.datatables.min.js"></script>

        <!-- <script type="text/javascript" src="/assets/js/bootstrap.min.js"></script> -->

    <!--/Datatables -->

<script type="text/javascript">
 $(document).ready(function()
  {
      
    $('.view').click(function(){
        var Id=$(this).attr('id');
        $.ajax({
          url:"modal.php?Id="+Id,
          cache:false,
          success:function(result){
            
            $(".modal-body").html(result);
        }});
    });

  });
</script>


</script>


<script type="text/javascript">
$(document).ready(function()
  {

     $(".editbox").hide();
        $(".text").show();
 
    $(document).mouseup(function()
    { 
        $(".editbox").hide();
        $(".text").show();
    });


    $(".edit_tr").click(function()
    {
        var ID=$(this).attr('id');
        //alert(ID);
        $("#first_"+ID).hide();
        //$("#second_"+ID).hide();
        $("#first_input_"+ID).show();
        //$("#second_input_"+ID).show();
    }).change(function()
        {
            var ID=$(this).attr('id');
            //alert(ID);
            var first=$("#first_input_"+ID).val();

            if(first==0)
            {
              alert("Please Enter Propar quantity");
              exit();
            }
            //alert(first);
            //var last=$("#last_input_"+ID).val();
            var dataString = 'id='+ ID +'&firstname='+first;
            //$("#first_"+ID).html('<img src="load.gif" />'); // Loading image

            if(first.length>0)
            {

                $.ajax({
                type: "POST",
                url: "stock_edit.php",
                data: dataString,
                cache: false,
                success: function(html)
                {
                    alert(html);
                    document.location.href="stock_master.php";
                    //$("#first_"+ID).html(first);
                    //$("#last_"+ID).html(last);
                }
              });
            }
            else
            {
                alert('Enter something.');
            }

      });

// Edit input box click action
$(".editbox").mouseup(function() 
{
  return false
});

// Outside click action
});
</script>


 
<script type="text/javascript">


  $(function() {
   // alert();
    
    $( "#bname" ).autocomplete({

      source:'booknamesearch.php'
      
    });

  });


</script>

<script type="text/javascript">
  $(document).ready(function(){
    $(document).on('submit', '#insert_form', function() {
       $.post("stock_insert.php", $(this).serialize())
       .done(function(data){
          //$("#insert").html('<div class="alert alert-info">'+data+'</div>');
                    alert(data);
                    //alert("Record Updated Successfully");
                    window.location.href="stock_master.php";
        });    
        return false;
      });
    });
</script>

<script type="text/javascript">
  $(document).ready(function(){
    $(document).on('change', '#qty', function() {
      
      var qty=$(this).val();

      if(qty=="0")
      {
        alert("quantity should not be zero");
        $("#qty").val('');
        $("#qty").focus();
        exit();
      }

      });
    });
</script>

  
<script type="text/javascript">
$(function(){
  $(".delete").click(function(){
            var id = $(this).attr("id");
           // alert(del_id);
            var del_id =id;
            //var parent = $(this).parent("td").parent("tr");
             if(confirm('Are You Sure want to delete ID no = ' +del_id+'?'))
            {
                $.post('delete_stock.php', {'del_id':del_id}, function(data)
                {
                    alert("Record Deleted Successfully");
                    window.location.href="stock_master.php";
                }); 
            }
        return false;
        });
});
</script>


  </head>

  <body>
  <!-- container section start -->
  <section id="container" class="">
      <!--header start-->


<?php

include('header.php');
include('sidebar.php');
?>

<!--main content start-->
      <section id="main-content">
          <section class="wrapper">
		  <div class="row">
				<div class="col-lg-12">
					<h3 class="page-header"><i class="fa fa-files-o"></i> Stock Master
					 <div class="navbar-form pull-right">
                                      <a href="bookmaster.php"><button class="btn btn-primary" type="button"><span class="fa fa-plus-square" aria-hidden="true"></span> Add Books</button></a>
                                    </div>
                         </h3>
				</div>
			</div>
              
              <div class="row">
                  <div class="col-md-12">
                      <section class="panel">
                          <header class="panel-heading">
                             Add Stock Details
                          </header>
                          <div class="panel-body">
                              <div class="form">
                               <form class="form-validate form-horizontal " id="insert_form" method="post" action="">
                                  
                                       <div class="form-group "> 
                                          <div class="ui-widget">
                                          
                                          <label for="" class="control-label col-md-1">Book Name <span class="required">*</span></label>
                                          <div class="col-md-2">
                                              <input class=" form-control" name="bname" id="bname" required="" />
                                          </div>
                                          </div>

                                          <label for="bname" class="control-label col-md-1">Quantity<span class="required">*</span></label>
                                          <div class="col-md-1">
                                              <input class="form-control "  name="qty" type="text" id="qty" required="" onkeypress="return isNumberKey(event)"/>
                                          </div>
                                                                  
                                          <label for="bprice" class="control-label col-md-1">Date <span class="required">*</span></label>
                                          <div class="col-md-2">
                                              <input class="form-control "  name="date" type="text" size="15" maxlength="4" onkeypress="return isNumberKey(event)" id="date" onkeyup="return calc()" value="<?php echo date('Y-m-d'); ?>" readonly/>
                                          </div>
                               
                                      
                                          <label for="bqty" class="control-label col-md-1">Book Status <span class="required">*</span></label>
                                           <div class="col-md-2">
                                         
                                          <select class="form-control" name="status">
                                            <option>new</option>
                                            <option>Damaged</option>
                                          </select>
                                          </div>
                                                      
                                      
                              
                                          
                                              <input class="btn btn-success" type="submit" name="btn-save" value="Save" id="btn-save">
                                              </div>

                      <div class="col-md-12">
                        <table class="table table-striped table-bordered table-advance table-hover display" id="myTable">
                            <thead>
                              <tr>
                                 <th> Stock id<i class="fa fa-sort"></i></th>
                                 <th>Book Id<i class="fa fa-sort"></i></th>
                                
                                 <th> Book Name<i class="fa fa-sort"></i></th>
                                  <th> Book Author<i class="fa fa-sort"></i></th>
                             
                                <th> Book Qty<i class="fa fa-sort"></i></th>
                                 <th> Date<i class="fa fa-sort"></i></th>
                                   
                                 <th><i class="icon_cogs"></i> Action</th>
                              </tr>
                            </thead>

                               <tbody>

                               <?php

                               require_once 'database.php';

                               $query=mysqli_query($con,"select distinct(book_name),book_author,s.book_id,stock_id,qty,date,status,sum(qty) from stock_master as s,book_master as b where b.book_id=s.book_id and qty!=0 group by book_name");

                               while($row=mysqli_fetch_array($query))
                               {
                                ?>

                                 <tr id="<?php echo $row['stock_id'];?>" class="">

                                  
                                 <td class='edit_td'><?php echo $row['stock_id'];?></td>
                                  
                                  <td class='edit_td'><?php echo $row['book_id'];?></td>
                                  <td class='edit_td'><?php echo $row['book_name'];?></td>
                                  <td class='edit_td'><?php echo $row['book_author'];?></td>
                                  
                                  <td class="edit_td">
                                  <span id="first_<?php echo $row['stock_id']; ?>" class="text"><?php echo $row['sum(qty)']; ?></span>
                                  <input type="text" value="<?php echo $row['qty']; ?>" class="form-control editbox" id="first_input_<?php echo  $row['stock_id']; ?>">
                                  </td>

                                  <td class='edit_td'><?php echo $row['date'];?></td>
                                 
                                 
                                 

                                  
                                <td>
                                  <div class="btn-group">
                                      <a id="<?php echo $row['stock_id']; ?>" href="#myModal" role="button" class="btn btn-primary view" data-toggle="modal"><i class="fa fa-eye"></i></a>
                                 
                                      <a id="<?php echo $row['stock_id']; ?>" href="" class="btn btn-danger delete"><i class="icon_close_alt2"></i></a>
                                  </div>
                                  

                                <?php
                               }
                               ?>

                               </tbody>

                               </table>


                   

                                              
                                              </div>
                                                   
                                          </div>
                                </div>
                                  </form>


                              </div>
                          </div>
                      </section>

                  </div>
              </div>
              <!-- page end-->
          </section>
      </section>
 <div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="myModalLabel">Detailed View of Book</h3>
      </div>
      <div class="modal-body">
        
      </div>
      <div class="modal-footer">
        <button class="btn btn-danger" data-dismiss="modal" aria-hidden="true">Cancel</button>
      </div>
    </div>
  </div>
</div>
     
<script type="text/javascript">
	 function isNumberKey(evt)
    {
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
        return true;
    }
</script>




<?php
include('footer.php');
?>