<?php

include('database.php');

//print_r($_POST);exit();

$category_name=$_POST['category_name'];
$bauthor=$_POST['bauthor'];
$bname=$_POST['bname'];
$bprice=$_POST['bprice'];
$bqty=$_POST['bqty'];
$totalprice=$_POST['totalprice'];
$bstatus=$_POST['bstatus'];
$barcode=$_POST['barcode'];

if($bstatus=="Available")
{
	$bstatus=0;
}
else
{
	$bstatus=1;
}
$date=date("Y-m-d");

$q=mysqli_query($con,"SELECT * FROM category_master WHERE category_name='$category_name'");

	while($row1=mysqli_fetch_array($q))
	{
		$category_id=$row1['category_id'];
	}
	
$query=mysqli_query($con,"SELECT * FROM book_master where book_name='$bname' and book_author='$bauthor'");

while($row=mysqli_fetch_array($query))
{
	$book_id=$row['book_id'];
	$book_name=$row['book_name'];
	$book_author=$row['book_author'];
}
	if($bname==$book_name && $bauthor==$book_author)
	{
		
		echo "<script>alert('This is an existing book and please update the stock');</script>";

		echo "<script>window.location.href='stock_master.php'</script>";
		
	}
	else
	{	
		$id=mysqli_query($con,"select max(book_id) from book_master");
		while($row0=mysqli_fetch_array($id))
		{
			$book_id=$row0['max(book_id)'];
			$b_id=$book_id+1;
			//echo $book_id;
		}

		$result=mysqli_query($con,"INSERT INTO book_master(book_author,book_category,book_name,book_price,book_qty,total_price,manufactur_date,book_status,barcode) values('$bauthor','$category_id','$bname','$bprice','$bqty','$totalprice','$date','$bstatus','$barcode')");

		$q=mysqli_query($con,"insert into stock_master(book_id,qty,date,status) values('$b_id','$bqty','$date','new')");



		$q1=mysqli_query($con,"SELECT * from book_master;");

		while($row2=mysqli_fetch_array($q1))
		{
			$bookid=$row2['book_id'];
		}

		$query4=mysqli_query($con,"INSERT INTO daily_updates(book_id,update_book_qty,mfdate) VALUES('$bookid','$bqty','$date')");

		echo "<script>alert('Book inserted sucessfully');</script>";

		echo "<script>window.location.href='bookmaster.php'</script>";
	}	

?>