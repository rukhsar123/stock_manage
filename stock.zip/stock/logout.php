<?php
	if(!isset($_SESSION["user"]))
	{
?>
		<script type="text/javascript">
		window.location="login.php";
        </script>
<?php
	}
	if($_SESSION["user"]!="")
	{
		//Nothing to do anything....
	}
?>	