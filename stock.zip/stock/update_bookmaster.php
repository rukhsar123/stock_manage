<?php
// Start the session
session_start();
 include ('logout.php');
include ('database.php');
?>
<!DOCTYPE html>
<html lang="en">
      <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    

    <title>Library Management</title>

    <!-- Bootstrap CSS -->    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
    <link rel="shortcut icon" href="img/favicon.png">
    
    <script src="jquery/jquery-3.1.1.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/jquery.dataTables.min.css">
    <script type="text/javascript" src="js/jquery.datatables.min.js"></script>

 </head>

  <body>
  <!-- container section start -->
  <section id="container" class="">
      <!--header start-->
    
        <?php
        include('header.php');
        include('sidebar.php');
        ?>
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
		  <div class="row">
				<div class="col-lg-12">
					<ol class="breadcrumb">
						<li><i class="fa fa-home"></i><a href="index.html">Dasboard</a></li>
						<li><i class="icon_document_alt"></i>Update Book Master Forms</li>
					</ol>
				</div>
			</div>


 <?php
// print_r($_GET);exit();
 $book_id=$_GET['book_id'];
$query=mysqli_query($con,"SELECT * FROM book_master WHERE book_id='$book_id'");

    while($row=mysqli_fetch_array($query))
    {
        $book_author=$row['book_author'];
        $book_name=$row['book_name'];
        $book_price=$row['book_price'];
        $book_qty=$row['book_qty'];
        $total=$book_price*$book_qty;
        $book_status=$row['book_status'];
        $book_category=$row['book_category'];
        $barcode=$row['barcode'];
    }
$q11=mysqli_query($con,"SELECT category_name from category_master where category_id='$book_category'");
while($row=mysqli_fetch_array($q11))
{
  $category_name=$row['category_name'];
}



?>


              
              <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                             Book Master
                          </header>
                          <div class="panel-body">
                              <div class="form">
                                  <form class="form-validate form-horizontal " id="update_form" method="post" action="">
                                      <div class="form-group ">
                                                    <label for="categoryname" class="control-label col-lg-2">Category Name<span class="required">*</span></label>
                                    <div class="col-lg-4">

                                    <?php 
                                            $query=mysqli_query($con,"SELECT * FROM category_master where category_name!='$category_name' ORDER BY category_name ASC");
                                            $rowCount = $query->num_rows;
                                            ?>

                                            <select name="category_name" id="category_name" class="form-control" required>
                                            <?php
                                                if($rowCount > 0)
                                                {
                                                while($row = $query->fetch_assoc()){ 
                                                echo '<option>'.$category_name.'</option>';
                                                echo '<option value="'.$row['category_id'].'">'.$row['category_name'].'</option>';
                                                 }
                                                }else{
                                                echo '<option value="">Category not available</option>';
                                                 }
                                            ?>
                                            </select>
                                        
                                          </div>

                                          <input type="hidden" name="id" value="<?php echo $book_id; ?>" required>
                                      
                                          <label for="bauthor" class="control-label col-lg-2">Book Author <span class="required">*</span></label>
                                          <div class="col-lg-4">
                                              <input class=" form-control" name="bauthor" type="text" value="<?php echo $book_author; ?>" required>
                                          </div>
                                      </div>
                                      <div class="form-group ">
                                          <label for="bname" class="control-label col-lg-2">Book Name <span class="required">*</span></label>
                                          <div class="col-lg-4">
                                              <input class="form-control " name="bname" type="text" value="<?php echo $book_name; ?>" required>
                                          </div>
                                                                         
                                          <label for="bprice" class="control-label col-lg-2">Book Price <span class="required">*</span></label>
                                          <div class="col-lg-4">
                                              <input class="form-control" name="bprice" type="text" value="<?php echo $book_price; ?>" required="" size="15" maxlength="4" onkeypress="return isNumberKey(event)" id="bprice" onkeyup="return calc()"/ >
                                          </div>
                                      </div>
                                      <div class="form-group ">
                                          <label for="bqty" class="control-label col-lg-2">Book Quantity <span class="required">*</span></label>
                                          <div class="col-lg-4">
                                              <input class="form-control " id="bqty" name="bqty" type="text" value="<?php echo $book_qty; ?>" required="" size="15" maxlength="4" onkeypress="return isNumberKey(event)" onkeyup="return calc()" readonly>
                                          </div>
                                                                         
                                          <label for="totalprice" class="control-label col-lg-2">Total Price <span class="required">*</span></label>
                                          <div class="col-lg-4">
                                              <input class="form-control" name="totalprice" type="text" value="<?php echo $total; ?>" required="" size="15" maxlength="4" id="totalprice" onkeypress="return isNumberKey(event)" readonly/ >
                                          </div>
                                      </div>
                                      <div class="form-group ">
                                          
                                          <label for="bstutus" class="control-label col-lg-2">Book Status <span class="required">*</span></label>
                                          <div class="col-lg-4">
                                          <input class="form-control " id="bstatus" name="bstatus" type="text" value="
                                          <?php 
                                            if($book_status == '0')
                                            {
                                               $yes="Available";
                                               echo $yes;
                                            }                                  
                                            if($book_status =='1')
                                            {
                                                $yes="Unavailable";
                                                echo $yes;    
                                            }
                                            ?>" readonly/>
                                           
                                          
                                          </div>
                                           <label for="barcode" class="control-label col-lg-2">Barcode Number <span class="required">*</span></label>
                                          <div class="col-lg-4">
                                              <input class="form-control "  name="barcode" type="text" size="15" maxlength="16" value="<?php echo $barcode; ?>" onkeypress="return isNumberKey(event)" id="barcode" />
                                          </div>
                                 
                                      </div>
                                      
                                      <div class="form-group">
                                          <div class="col-lg-offset-2 col-lg-10">
                                              <button class="btn btn-primary" type="submit">Update</button>
                                              <!--<button class="btn btn-default" type="button">Reset</button>-->
                                          </div>
                                      </div>
                                  </form>
                              </div>
                          </div>
                      </section>
                  </div>
              </div>
              <!-- page end-->
          </section>
      </section>
      <!--main content end-->
      <div class="text-right">
        <div class="credits">
            <!-- 
                All the links in the footer should remain intact. 
                You can delete the links only if you purchased the pro version.
                Licensing information: https://bootstrapmade.com/license/
                Purchase the pro version form: https://bootstrapmade.com/buy/?theme=NiceAdmin
            
            <a href="https://bootstrapmade.com/free-business-bootstrap-themes-website-templates/">Business Bootstrap Themes</a> by <a href="https://bootstrapmade.com/">BootstrapMade</a>-->
        </div>
    </div>
  </section>
  <!-- container section end -->
    <?php include ('footer.php');?>
    <script>

    //Empty Field Validation
    var Script = function () {
    $().ready(function() {
        // validate the comment form when it is submitted
        $("#feedback_form").validate();

        // validate signup form on keyup and submit
        $("#register_form").validate({
            rules: {
                category_name: {
                    required: true,
                },
                bauthor: {
                    required: true,
                },
                bname: {
                    required: true,
                },
                bprice: {
                    required: true,
                },
                bqty: {
                    required: true,
                },
                bstatus: {
                    required: true,
                },
            },
            messages: {                
                category_name: {
                    required: "Please Select Category Name.",
                },
                bauthor: {
                    required: "Please enter a  Book Author.",
                },
                bname: {
                    required: "Please enter a Book Name.",
                },
                bprice: {
                    required: "Please provide a Book Price.",
                },
                bqty: {
                    required: "Please provide a Book Quantity.",
                },
                bstatus: {
                    required: "Please provide a Book status.",
                },
                
            }
        });
    });
}();

    //Enter key Number Validation
    function isNumberKey(evt)
    {
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
        return true;
    }

    function calc()
    {
        var bookprice = document.getElementById('bprice').value;
        var bookqty = document.getElementById('bqty').value;
        document.getElementById('totalprice').value = bookprice*bookqty; 
    }

    $(document).ready(function() {
 
    $("#bqty").change(function(){
 
        var book_qty = $(this).val();
        var book_status = $(this).val();
        if(book_qty==0 && book_qty<=0)
        {
            alert('Book Quantity Must not be zero or less than zero');
            $("#bstatus").val('Unavailable');
            $("#bqty").focus();
        }

        if(book_qty!=0 && book_qty>0)
        {
            $("#bstatus").val('Available');            
        }     
    });
 
    });
    </script>

    <script type="text/javascript">
    $(document).ready(function(){

         $("#update_form").find("#bqty").on("change",function(){
            var qty=$('input:text[name=bqty]').val();
            
        
            if(qty!=0 && qty>0)
            {
                var change_status="Available";
                $("#bstatus").val(change_status);
                 $.post("update_book.php", $(this).serialize())
            }
            else
            {
                var change_status="Unavailable";
                $("#bstatus").val(change_status);
                 $.post("update_book.php", $(this).serialize())
            
            }
        });
    



        $(document).on('submit', '#update_form', function() {
     
       $.post("update_book.php", $(this).serialize())
       .done(function(data){

                    $("#update_form").html('<div class="alert alert-info">'+data+'</div>');
                        // alert($data);                 
                    alert("Record Updated Successfully");
                    window.location.href="view_book.php";
                                 
                    });    
        
        return false;
   
        });


    });
    
    </script>

  </body>
</html>
