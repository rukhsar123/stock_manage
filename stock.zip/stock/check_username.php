
             <?php

             	$username=$_POST['username'];
             	

             	//echo $username;
                require_once 'database.php';                


               $query=mysqli_query($con,"select count(*) from admin_login where username='$username'") or die(mysqli_error());
                $row=mysqli_fetch_array($query);
                
                    $user_count=$row[0];

                    if(!$user_count>0)
					{
						echo "Username Not Available.";
					?>

					<script type="text/javascript">
						$("#username").val('');
                    	document.form1.username.focus();
                     
					</script>

				<?php	
					}
                 ?>

            



