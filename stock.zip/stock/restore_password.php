<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Login Page </title>

    <!-- Bootstrap CSS -->    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
  <script src="js/jquery.js"></script>

</head>

<script type="text/javascript">

$(document).ready(function(){

$(document).on('submit','#login_form',function(){
    
    
        var newpwd=$('#newpwd').val();
        var cnewpwd=$('#cnewpwd').val();
        
        if(newpwd==cnewpwd)
        {
             jQuery.ajax({
                url: "dbrestore_password.php",
                data:'newpwd='+$("#newpwd").val(),
                type: "POST",
                success:function(data)
                {
                    alert(data);
                    document.location.href="login.php";
                   // $(".output").html(data);
                     //$("#loaderIcon").hide();
                },
                error:function (){}
                
                });            

            

        }
        else
        {
            alert("New Password and Confirm Password doesn't Match!");
            document.form1.newpwd.focus();
            
        }
    
        return false;
    });
});       
    
        

</script>


  <body class="login-img3-body">

    <div class="container">

      <form class="form-validate login-form " method="post" name="form1" id="login_form" style="margin: 120px auto 0 !important;">        
        <div class="login-wrap">
            <p class="login-img"><i class="icon_lock_alt"></i></p>
            <p>Change Passoword</p>

           
            <div class="input-group">
                <span class="input-group-addon"><i class="icon_key_alt"></i></span>
                <input type="password" class="form-control" name="newpwd" id="newpwd" placeholder="New Password" required="" size="15" maxlength="8" >
            
            </div>

            <div class="input-group">
                <span class="input-group-addon"><i class="icon_key_alt"></i></span>
                <input type="password" class="form-control" name="cnewpwd" id="cnewpwd" placeholder="Confirm New Password" required="" size="15" maxlength="8" >
            
            </div>
            
           <!-- <label class="checkbox">
                <span class="pull-left"> <a href="login.php"> Admin Login</a></span>
            
                <span class="pull-right"> <a href="forgot_password.php"> Forgot Password?</a></span>
            </label>-->
            <button class="btn btn-primary btn-lg btn-block" type="submit" id="login">Change Password</button>
            
        </div>
    
            </form>
        </div>
    
  </body>
</html>

