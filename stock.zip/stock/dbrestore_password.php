<?php

require_once 'database.php';

	if(isset($_COOKIE["cookie"]))
	{
		$newpwd=$_POST['newpwd'];
	
		$username=$_COOKIE["cookie"];
		//echo $username;
	
	
	mysqli_query($con,"update admin_login set password='$newpwd' where username='$username'") or die(mysqli_error());

		echo "Password Change Successfully";
	
	}
?>