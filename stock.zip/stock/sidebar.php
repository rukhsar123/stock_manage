<!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu">                
                  <li class="">
                      <a class="" href="index.php">
                          <i class="icon_house_alt"></i>
                          <span>Dashboard</span>
                      </a>
                  </li>
                   <li class="sub-menu">
                      <a class="" href="view_book.php">
                          <i class="icon_document_alt"></i>
                          <span>Book Master</span>
                      </a>
                  </li>
                  <li class="sub-menu">
                      <a class="" href="stock_master.php">
                          <i class="icon_genius"></i>
                          <span>Stock Master</span>
                      </a>
                  </li> 
                  </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->