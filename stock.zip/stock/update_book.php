<?php
require_once 'database.php';

	//print_r($_POST);exit();
	if($_POST)
	{
		$id=$_POST['id'];
		echo $id;
		$bcategory = $_POST['category_name'];
		$bauthor = $_POST['bauthor'];
		$bname = $_POST['bname'];
		$bprice = $_POST['bprice'];
		$bqty = $_POST['bqty'];
		$totalprice=$_POST['totalprice'];
		$bstatus = $_POST['bstatus'];
		$barcode = $_POST['barcode'];

		$sql=mysqli_query($con,"select category_id from category_master where category_name='$bcategory'") or die(mysqli_error());

		while($row=mysqli_fetch_array($sql))
		{
			$category_id=$row['category_id'];
		}
		
		if($bstatus=="Unavailable")
		{
			$status=1;
		}
		if($bstatus=="Available")
		{
			$status=0;
		}
		
		$query = mysqli_query($con,"UPDATE book_master SET book_author='$bauthor', book_name='$bname',book_price='$bprice',book_category='$category_id',book_qty='$bqty',total_price='$totalprice',book_status='$bstatus', barcode='$barcode' WHERE book_id='$id'") or die(mysqli_error());

		
		
	}

?>