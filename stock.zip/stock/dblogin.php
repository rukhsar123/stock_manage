<?php
// Start the session
session_start();
include ('database.php');
 if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      $username = mysqli_real_escape_string($con,$_POST['username']);
      $password = mysqli_real_escape_string($con,$_POST['password']); 
      $role = mysqli_real_escape_string($con,$_POST['role']); 
      
        $sql = "SELECT id FROM admin_login WHERE username = '$username' and password = '$password' and role = '$role' ";
        $result = mysqli_query($con,$sql);
        $count = mysqli_num_rows($result);
      // If result matched $myusername and $mypassword, table row must be 1 row  
      if($count == 1) {
         $_SESSION['user'] = $username;

          echo 'success';
      }else {
         echo  "Your Role or Login Name or Password is invalid";
      }   
    }
    ?>